package ServerFunctions;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class pAddtoInventory
 */
@WebServlet("/pAddtoInventory")
public class pAddtoInventory extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public pAddtoInventory() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String name = request.getParameter("productName");
		String quantity = request.getParameter("quantity");
		String dateRecieved = request.getParameter("dateRecieved");
		String unitPrice = request.getParameter("unitPrice");
		String id = null;
		String nameTest = "SELECT MaterialID  FROM inventory WHERE MaterialName = '"+name+"'";
		// check if entered name already exists in database and if it does get id
		MysqlUtils mysql = new MysqlUtils();
		try {
			
			id=mysql.qetdetail(nameTest);
			if(id != null){
				//get current products quantity and add new quantity
				int id2=Integer.parseInt(id);
				//create statement to get current number of in stock products
				String quantityTest = "SELECT InStockNo  FROM inventory WHERE MaterialName = '"+name+"'";
				int newquantity=Integer.parseInt(quantity)+Integer.parseInt(mysql.qetdetail(quantityTest));
				String sql ="UPDATE inventory SET InStockNo ="+newquantity+" ,Date_Updated = CURRENT_TIMESTAMP  WHERE MaterialID = "+id2;
				mysql.insertBySql(sql);
				response.sendRedirect("order.jsp?sen=success2");
			}
			else {
				//execute insert of products into table
		
					//get id number used
					int maxno= mysql.queryMaxNo("inventory");
					maxno = maxno + 1;
					//create sql statement to insert new row into database
					String sql="INSERT INTO inventory ( MaterialID, MaterialName, Unit_Price, InStockNo, Date_Added, Date_Updated) VALUES ( "+maxno+", '"+name+"',"+ unitPrice +","+ quantity +", CURRENT_TIMESTAMP, CURRENT_TIMESTAMP  )";
					//execute insert statement
					mysql.insertBySql(sql);
					response.sendRedirect("order.jsp?sen=success");
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
