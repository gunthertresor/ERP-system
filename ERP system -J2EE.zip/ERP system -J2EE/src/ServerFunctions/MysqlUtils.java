package ServerFunctions;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MysqlUtils {
	private String mysqlURL ="jdbc:mysql://localhost:3306/erpdatabase";
	
		
		//used to add data to database using insert function to selected table
		public void insertBySql(String sql) throws SQLException{
			Connection conn =null;
			try{
				Class.forName("com.mysql.jdbc.Driver").newInstance();
				conn = DriverManager.getConnection(mysqlURL, "root","");
				Statement stmt = conn.createStatement();
				stmt.executeUpdate(sql);
				
			}catch (Exception e) {
				e.printStackTrace();
			}finally{
				if(null!=conn)
					conn.close();
			}
		}
		
		// function used to query the number of rows in selected table
		public Integer queryMaxNo(String cat) throws SQLException{
			Connection conn = null;
			try{
				Class.forName("com.mysql.jdbc.Driver").newInstance();
				conn = DriverManager.getConnection(mysqlURL, "root","");
				Statement stmt = conn.createStatement();
				String sql = "SELECT COUNT(*) FROM "+cat;
				ResultSet rs = stmt.executeQuery(sql);
				while(rs.next()){
					return rs.getInt(1);
				}
			}catch (Exception e){
				e.printStackTrace();
			}finally{
				if(null!=conn)
					conn.close();
			}
			return 0;
		}
		
		//function used to get selected data from table using a select statement
		public String qetdetail(String sql) throws SQLException{
			Connection conn = null;
			try{
				Class.forName("com.mysql.jdbc.Driver").newInstance();
				conn = DriverManager.getConnection(mysqlURL, "root","");
				Statement stmt = conn.createStatement();
				
				ResultSet rs = stmt.executeQuery(sql);
				while(rs.next()){
					String value = rs.getString(1);
					return value;
				}
			}catch (Exception e){
				e.printStackTrace();
			}finally{
				if(null!=conn)
					conn.close();
			}
			return null;
		}
		
		
	}



