package ServerFunctions;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class newCustomer
 */
@WebServlet("/newCustomer")
public class newCustomer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public newCustomer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		

		HttpSession session = request.getSession();
		String name= request.getParameter("customerName");
		String phone= request.getParameter("phone");
		String email= request.getParameter("email");
		String address= request.getParameter("address");
		
		MysqlUtils mysql= new MysqlUtils();
		
		Integer status = (Integer)session.getAttribute("status");
		
		try {
		if(status != null){
			int id=mysql.queryMaxNo("customer")+1;
			String sql="INSERT INTO customer ( CustomerID, CustomerName, CustomerAddress, Phone, Email) VALUES ( "+id+", '"+name+"','"+ address +"','"+ phone +"','"+ email+"')";
			//execute insert statement
			mysql.insertBySql(sql);
			
			int index = (mysql.queryMaxNo("salesorders"))+1;
			int findex=index;
			int salesOrderId = (mysql.queryMaxNo("saleordercheck"))+1;
			int numberOfItems=0;
			List cart = (List)session.getAttribute("cart");
			for( int i = 0 ; i < cart.size() ; i ++ ){
				Product item = (Product)cart.get(i);
				
			    int itemId =Integer.parseInt( item.getMaterialNo());
				int quantity = item.getQuantity();
				numberOfItems = numberOfItems +1;
				//insert into salesOrders
				 sql="INSERT INTO salesorders ( id, salesOrderID, itemId, quantity) VALUES ( "+index+", "+salesOrderId+","+ itemId +","+ quantity +")";
				mysql.insertBySql(sql);
				index = index+1;
			}
			//insert into sales order check table
			
			 sql="INSERT INTO saleordercheck ( salesOrderId, customerId, date, id, numberOfItems) VALUES ( "+salesOrderId+", "+id+", CURRENT_TIMESTAMP,"+ findex +","+ numberOfItems+")";
			//execute insert statement
			mysql.insertBySql(sql); 
			
			//insert salesorders to warehouse worklist
			int primarykey = (mysql.queryMaxNo("wmworklist"))+1;
			sql="INSERT INTO wmworklist ( primarykey, salesorderno, customerid) VALUES ( "+primarykey+","+salesOrderId+", "+id +")";
			mysql.insertBySql(sql);
		
			status=null;
			cart.clear();
			session.setAttribute("cart", cart);
			session.setAttribute("status", status);
			response.sendRedirect("CreateSO.jsp");
		}else{
			int id=mysql.queryMaxNo("customer")+1;
			
			String sql="INSERT INTO customer ( CustomerID, CustomerName, CustomerAddress, Phone, Email) VALUES ( "+id+", '"+name+"','"+ address +"','"+ phone +"','"+ email+"')";
	
			mysql.insertBySql(sql);
			status=null;
			session.setAttribute("status", status);
			response.sendRedirect("Customers");	 
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
