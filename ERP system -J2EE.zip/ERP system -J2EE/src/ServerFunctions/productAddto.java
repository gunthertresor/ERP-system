package ServerFunctions;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class productAddto
 */
@WebServlet("/productAddto")
public class productAddto extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public productAddto() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		// recieves product name from form in productadd.jsp page when button is clicked
		String pname= request.getParameter("productName");
		int quantity =Integer.parseInt(request.getParameter("quantity"));
		
		List cart = (List)session.getAttribute("cart");

		if( null == cart||cart.size()<=0){
			cart = new ArrayList();
		}
		//after new cart is intialised if no cart has been created 
			 try{
				 
				 MysqlUtils mysql= new MysqlUtils();
				//	program then checks if cart already gas item in cart or adds item to cart			 
				 boolean flag = false;
					for(int i=0;i<cart.size();i++){
						Product bi = (Product)cart.get(i);
						if(bi.getMaterialNo().equals(mysql.qetdetail("SELECT MaterialID  FROM inventory WHERE MaterialName ='"+pname+"'"))){
							bi.setQuantity(bi.getQuantity()+quantity);
							bi.setTotal();
							flag = true;
						}
					}
					
					if(!flag){
						Product p= new Product();;
						 p.setMaterialNo(mysql.qetdetail("SELECT MaterialID  FROM inventory WHERE MaterialName ='"+pname+"'"));
						 p.setMaterialDescription(pname);
						 p.setQuantity(quantity);
						 p.setUnitPrice(Integer.parseInt(mysql.qetdetail("SELECT Unit_Price  FROM inventory WHERE MaterialName ='"+pname+"'")));
						 p.setTotal();
						cart.add(p);
					}
				 			
				}catch(SQLException e){
					e.printStackTrace();}
			
			 session.setAttribute("cart", cart);
			 response.sendRedirect("CreateSO.jsp");
		
	} 

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
