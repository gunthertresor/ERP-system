package ServerFunctions;

public class salesOrder {
		private int materialId;
		private String materialName;
		private int unitPrice;
		private int quantity;
		private int inStock;
		private int total;
		private int customerId;
		private int grandTotal;
		
		
		public int getQuantity() {
			return quantity;
		}
		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}
		public int getMaterialId() {
			return materialId;
		}
		public void setMaterialId(int materialId) {
			this.materialId = materialId;
		}
		public String getMaterialName() {
			return materialName;
		}
		public void setMaterialName(String materialName) {
			this.materialName = materialName;
		}
		public int getUnitPrice() {
			return unitPrice;
		}
		public void setUnitPrice(int unitPrice) {
			this.unitPrice = unitPrice;
		}
		public int getInStock() {
			return inStock;
		}
		public void setInStock(int inStock) {
			this.inStock = inStock;
		}
		public int getTotal() {
			return total;
		}
		public void setTotal(int total) {
			this.total = total;
		}
		public int getCustomerId() {
			return customerId;
		}
		public void setCustomerId(int customerId) {
			this.customerId = customerId;
		}
		public int getGrandTotal() {
			return grandTotal;
		}
		public void setGrandTotal(int grandTotal) {
			this.grandTotal = grandTotal;
		}
		
		
		
		
}
