package ServerFunctions;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// servlet used to check login information and open different page for different user
/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// gets name and password from form in login.jsp page on button click
		String name = request.getParameter("name");
		String password = request.getParameter("password");
		int employeeid = Integer.parseInt(request.getParameter("employeeid"));
		
		// a redirect page is intialised to redirect to login page if name or user name are incorrect
		String redirect = "index.jsp?sen=Incorrect";
		String newname,newpassword,department;
		MysqlUtils mysql= new MysqlUtils();
		// int i,rows = 0;
		try {
			
				 
					 String nameTest = "SELECT NAME FROM employees WHERE employeeid = "+employeeid;
					 String passwordTest ="SELECT PASSWORD FROM employees WHERE employeeid = "+employeeid;
					 String departmentTest ="SELECT DEPARTMENT FROM employees WHERE employeeid = "+employeeid;
					 
						newname=mysql.qetdetail(nameTest);
						newpassword=mysql.qetdetail(passwordTest);
						department=mysql.qetdetail(departmentTest);
						
						if(name.equals(newname)){
							if(password.equals(newpassword)){
								
								if(department.equals("sales")){redirect="SalesManFirst.jsp";}
								
								else if(department.equals("warehouse")){redirect="wareHouseFirst.jsp";}
								
								else if(department.equals("accounting")){redirect="accountingFirst.jsp";}	
								
								else if(department.equals("procurement")){redirect="procurementFirst.jsp";}	
							}
													
						}
			
			 		
			 
			 response.sendRedirect(redirect);
			 }catch(SQLException e){
					e.printStackTrace();}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
