package ServerFunctions;

import java.sql.SQLException;


public class Product {
	private int Quantity;
	private String MaterialNo;
	private String MaterialDescription;
	private int UnitPrice;
	private int Total;

	
	public int getQuantity() {
		return Quantity;
	}
	public void setQuantity(int quantity) {
		Quantity = quantity;
	}
	public String getMaterialNo() {
		return MaterialNo;
	}
	public void setMaterialNo(String materialNo) {
		MaterialNo = materialNo;
	}
	public String getMaterialDescription() {
		return MaterialDescription;
	}
	public void setMaterialDescription(String materialDescription) {
		MaterialDescription = materialDescription;
	}
	public int getUnitPrice() {
		return UnitPrice;
	}
	public void setUnitPrice(int unitPrice) {
		UnitPrice = unitPrice;
	}
	public int getTotal() {
		return Total;
	}
	public void setTotal() {
		Total = getQuantity() * getUnitPrice();
	}
	
	
}
